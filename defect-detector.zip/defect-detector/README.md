# Steel Surface Defect Detector

Classifies images of steel surfaces into defect types using a fine-tuned ResNet18 (PyTorch), with evaluation, Grad-CAM explainability and a FastAPI service packaged with Docker.

> TODO after you run it: add your real results (accuracy, F1 per class), a confusion matrix image and a Grad-CAM example below.

## Dataset
NEU Surface Defect Database (6 defect classes, ~1,800 grayscale images). Download it (for example from Kaggle), check its license, and arrange the images as `raw/<class_name>/*.bmp`.

## Setup
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

## Usage
```bash
python -m src.data --src raw --out data/split        # stratified train/val/test split
python -m src.train --epochs 10                      # fine-tune ResNet18, saves models/best.pt
python -m src.evaluate                               # metrics, confusion matrix, misclassified list
python -m src.gradcam path/to/image.bmp              # Grad-CAM heatmap
uvicorn app:app --reload                             # API docs at http://127.0.0.1:8000/docs
pytest                                               # run tests
```

## Docker
```bash
docker build -t defect-detector .
docker run -p 8000:8000 defect-detector
```
Then open http://localhost:8000/docs and use `/predict` to upload an image.

## Results
_Fill in after training: test accuracy, per-class precision/recall/F1, confusion matrix, and your error analysis (why were some images misclassified?)._

## Tech stack
Python, PyTorch, torchvision, scikit-learn, Matplotlib, FastAPI, Docker, pytest, Git
