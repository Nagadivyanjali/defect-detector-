"""FastAPI service: POST an image to /predict to get the predicted defect class."""
import io
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, UploadFile
from PIL import Image, UnidentifiedImageError

from src.inference import load_model, predict

MODEL_PATH = Path("models/best.pt")
app = FastAPI(title="Surface Defect Detector")
_state = {}


@app.on_event("startup")
def startup():
    if MODEL_PATH.exists():
        _state["model"], _state["classes"] = load_model(str(MODEL_PATH))


@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": "model" in _state}


@app.post("/predict")
async def predict_endpoint(file: UploadFile = File(...)):
    if "model" not in _state:
        raise HTTPException(status_code=503, detail="Model not loaded. Train a model first.")
    try:
        image = Image.open(io.BytesIO(await file.read()))
    except UnidentifiedImageError:
        raise HTTPException(status_code=400, detail="Uploaded file is not a valid image.")
    return predict(_state["model"], _state["classes"], image)
