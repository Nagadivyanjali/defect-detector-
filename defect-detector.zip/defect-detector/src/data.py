"""Dataset utilities: stratified splitting and PyTorch data loaders."""
import random
import shutil
from pathlib import Path

from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

IMG_SIZE = 224
MEAN, STD = [0.485, 0.456, 0.406], [0.229, 0.224, 0.225]


def train_transform():
    return transforms.Compose([
        transforms.Grayscale(num_output_channels=3),
        transforms.Resize((IMG_SIZE, IMG_SIZE)),
        transforms.RandomHorizontalFlip(),
        transforms.RandomRotation(10),
        transforms.ColorJitter(brightness=0.2, contrast=0.2),
        transforms.ToTensor(),
        transforms.Normalize(MEAN, STD),
    ])


def eval_transform():
    return transforms.Compose([
        transforms.Grayscale(num_output_channels=3),
        transforms.Resize((IMG_SIZE, IMG_SIZE)),
        transforms.ToTensor(),
        transforms.Normalize(MEAN, STD),
    ])


def split_dataset(src_dir, out_dir, val_size=0.15, test_size=0.15, seed=42):
    """Copy images from src_dir/<class>/* into out_dir/{train,val,test}/<class>/*."""
    src_dir, out_dir = Path(src_dir), Path(out_dir)
    random.seed(seed)
    for class_dir in sorted(p for p in src_dir.iterdir() if p.is_dir()):
        files = sorted(f for f in class_dir.iterdir() if f.is_file())
        train_f, rest = train_test_split(files, test_size=val_size + test_size, random_state=seed)
        val_f, test_f = train_test_split(rest, test_size=test_size / (val_size + test_size), random_state=seed)
        for split, items in (("train", train_f), ("val", val_f), ("test", test_f)):
            target = out_dir / split / class_dir.name
            target.mkdir(parents=True, exist_ok=True)
            for f in items:
                shutil.copy2(f, target / f.name)
    print(f"Split written to {out_dir}")


def get_loader(data_dir, split, batch_size=32, shuffle=False):
    tfm = train_transform() if split == "train" else eval_transform()
    ds = datasets.ImageFolder(Path(data_dir) / split, transform=tfm)
    return DataLoader(ds, batch_size=batch_size, shuffle=shuffle, num_workers=0), ds.classes


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description="Split a class-folder dataset into train/val/test")
    p.add_argument("--src", required=True, help="folder with one sub-folder per class")
    p.add_argument("--out", default="data/split")
    args = p.parse_args()
    split_dataset(args.src, args.out)
