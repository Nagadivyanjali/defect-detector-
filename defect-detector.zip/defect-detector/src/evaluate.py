"""Evaluate on the test set: per-class metrics, confusion matrix, misclassified list."""
import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import torch
from sklearn.metrics import ConfusionMatrixDisplay, classification_report, confusion_matrix

from src.data import get_loader
from src.inference import load_model


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="data/split")
    p.add_argument("--model", default="models/best.pt")
    args = p.parse_args()

    model, classes = load_model(args.model)
    device = next(model.parameters()).device
    loader, _ = get_loader(args.data, "test")
    paths = [s[0] for s in loader.dataset.samples]

    y_true, y_pred = [], []
    with torch.no_grad():
        for images, labels in loader:
            preds = model(images.to(device)).argmax(1).cpu()
            y_true += labels.tolist()
            y_pred += preds.tolist()

    print(classification_report(y_true, y_pred, target_names=classes, digits=3))

    Path("outputs").mkdir(exist_ok=True)
    cm = confusion_matrix(y_true, y_pred)
    ConfusionMatrixDisplay(cm, display_labels=classes).plot(xticks_rotation=45, cmap="Blues")
    plt.tight_layout()
    plt.savefig("outputs/confusion_matrix.png", dpi=150)

    wrong = [f"{paths[i]}  true={classes[t]}  predicted={classes[p_]}"
             for i, (t, p_) in enumerate(zip(y_true, y_pred)) if t != p_]
    Path("outputs/misclassified.txt").write_text("\n".join(wrong))
    print(f"{len(wrong)} misclassified images listed in outputs/misclassified.txt (use these for error analysis)")


if __name__ == "__main__":
    main()
