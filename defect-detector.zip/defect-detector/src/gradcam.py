"""Grad-CAM heatmap for a single image (shows where the model looks)."""
import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch.nn.functional as F
from PIL import Image

from src.inference import load_model, preprocess


def grad_cam(model, tensor, class_idx=None):
    layer = model.layer4[-1]
    store = {}
    h1 = layer.register_forward_hook(lambda m, i, o: store.__setitem__("act", o))
    h2 = layer.register_full_backward_hook(lambda m, gi, go: store.__setitem__("grad", go[0]))
    model.zero_grad()
    output = model(tensor)
    if class_idx is None:
        class_idx = output.argmax(1).item()
    output[0, class_idx].backward()
    h1.remove()
    h2.remove()

    weights = store["grad"].mean(dim=(2, 3), keepdim=True)
    cam = F.relu((weights * store["act"]).sum(dim=1, keepdim=True))
    cam = F.interpolate(cam, size=tensor.shape[2:], mode="bilinear", align_corners=False)[0, 0]
    cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
    return cam.detach().cpu().numpy(), class_idx


def main():
    p = argparse.ArgumentParser()
    p.add_argument("image")
    p.add_argument("--model", default="models/best.pt")
    p.add_argument("--out", default="outputs/gradcam.png")
    args = p.parse_args()

    model, classes = load_model(args.model)
    device = next(model.parameters()).device
    img = Image.open(args.image)
    tensor = preprocess(img).to(device)
    tensor.requires_grad_(True)
    cam, idx = grad_cam(model, tensor)

    base = np.array(img.convert("L").resize(cam.shape[::-1]))
    plt.imshow(base, cmap="gray")
    plt.imshow(cam, cmap="jet", alpha=0.4)
    plt.title(f"Predicted: {classes[idx]}")
    plt.axis("off")
    Path(args.out).parent.mkdir(exist_ok=True)
    plt.savefig(args.out, dpi=150, bbox_inches="tight")
    print(f"Saved {args.out}")


if __name__ == "__main__":
    main()
