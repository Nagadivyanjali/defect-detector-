"""Shared loading and preprocessing used by evaluation, Grad-CAM and the API."""
import torch
from PIL import Image

from src.data import eval_transform
from src.model import build_model, get_device


def load_model(path="models/best.pt"):
    device = get_device()
    checkpoint = torch.load(path, map_location=device)
    classes = checkpoint["classes"]
    model = build_model(len(classes), pretrained=False)
    model.load_state_dict(checkpoint["state_dict"])
    model.to(device).eval()
    return model, classes


def preprocess(image: Image.Image):
    return eval_transform()(image.convert("L")).unsqueeze(0)


def predict(model, classes, image: Image.Image):
    device = next(model.parameters()).device
    with torch.no_grad():
        probs = torch.softmax(model(preprocess(image).to(device)), dim=1)[0]
    conf, idx = probs.max(0)
    return {"label": classes[idx.item()], "confidence": round(conf.item(), 4)}
