import torch
from torch import nn
from torchvision import models


def build_model(num_classes, pretrained=True):
    weights = models.ResNet18_Weights.DEFAULT if pretrained else None
    model = models.resnet18(weights=weights)
    model.fc = nn.Linear(model.fc.in_features, num_classes)
    return model


def get_device():
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")
