"""Fine-tune a pretrained ResNet18 on the defect dataset."""
import argparse
import json
from pathlib import Path

import torch
from torch import nn

from src.data import get_loader
from src.model import build_model, get_device


def run_epoch(model, loader, criterion, device, optimizer=None):
    training = optimizer is not None
    model.train(training)
    total_loss, correct, count = 0.0, 0, 0
    with torch.set_grad_enabled(training):
        for images, labels in loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            loss = criterion(outputs, labels)
            if training:
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
            total_loss += loss.item() * images.size(0)
            correct += (outputs.argmax(1) == labels).sum().item()
            count += images.size(0)
    return total_loss / count, correct / count


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="data/split")
    p.add_argument("--epochs", type=int, default=10)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--batch-size", type=int, default=32)
    p.add_argument("--out", default="models/best.pt")
    args = p.parse_args()

    device = get_device()
    train_loader, classes = get_loader(args.data, "train", args.batch_size, shuffle=True)
    val_loader, _ = get_loader(args.data, "val", args.batch_size)

    model = build_model(len(classes)).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

    best_acc, history = 0.0, []
    for epoch in range(1, args.epochs + 1):
        tr_loss, tr_acc = run_epoch(model, train_loader, criterion, device, optimizer)
        va_loss, va_acc = run_epoch(model, val_loader, criterion, device)
        history.append({"epoch": epoch, "train_loss": tr_loss, "train_acc": tr_acc, "val_loss": va_loss, "val_acc": va_acc})
        print(f"Epoch {epoch}/{args.epochs}  train loss {tr_loss:.4f} acc {tr_acc:.3f} | val loss {va_loss:.4f} acc {va_acc:.3f}")
        if va_acc > best_acc:
            best_acc = va_acc
            Path(args.out).parent.mkdir(parents=True, exist_ok=True)
            torch.save({"state_dict": model.state_dict(), "classes": classes}, args.out)

    Path("outputs").mkdir(exist_ok=True)
    Path("outputs/history.json").write_text(json.dumps(history, indent=2))
    print(f"Best validation accuracy: {best_acc:.3f}. Model saved to {args.out}")


if __name__ == "__main__":
    main()
