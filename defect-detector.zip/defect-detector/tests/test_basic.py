from fastapi.testclient import TestClient
from PIL import Image

from app import app
from src.inference import preprocess


def test_preprocess_output_shape():
    img = Image.new("L", (200, 200))
    assert preprocess(img).shape == (1, 3, 224, 224)


def test_health_endpoint():
    with TestClient(app) as client:
        response = client.get("/health")
        assert response.status_code == 200
        assert "model_loaded" in response.json()


def test_predict_without_model_returns_503():
    with TestClient(app) as client:
        if client.get("/health").json()["model_loaded"]:
            return  # a trained model exists locally; skip this check
        response = client.post("/predict", files={"file": ("x.png", b"not-an-image", "image/png")})
        assert response.status_code == 503
